chrome.extension.sendRequest({action: "run"}, function(response) {
    // send a request to background.js
});
